from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from pathlib import Path
from functools import wraps

app = Flask(__name__)
app.secret_key = "replace-with-a-long-random-secret-before-deployment"
DB = Path(__file__).with_name("rental.db")

# EDIT THIS LIST to add cars or change daily prices (in Indian rupees).
CARS = [
    {"id": 101, "name": "Innova Crysta", "brand": "Toyota", "price": 4000, "image": "🚙"},
    {"id": 102, "name": "Swift", "brand": "Maruti Suzuki", "price": 1500, "image": "🚗"},
    {"id": 103, "name": "Civic", "brand": "Honda", "price": 3500, "image": "🚘"},
    {"id": 104, "name": "Fortuner", "brand": "Toyota", "price": 5000, "image": "🚙"},
    {"id": 105, "name": "Polo GT", "brand": "Volkswagen", "price": 3000, "image": "🚗"},
    {"id": 106, "name": "Verna", "brand": "Hyundai", "price": 3200, "image": "🚘"},
    {"id": 107, "name": "Rapid", "brand": "Skoda", "price": 2700, "image": "🚗"},
    {"id": 108, "name": "EcoSport", "brand": "Ford", "price": 2500, "image": "🚙"},
    {"id": 109, "name": "Nexon", "brand": "Tata", "price": 2200, "image": "🚘"},
    {"id": 110, "name": "Creta", "brand": "Hyundai", "price": 3500, "image": "🚙"},
]

def db_conn():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def init_db():
    with db_conn() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id),
            car_id INTEGER NOT NULL,
            car_name TEXT NOT NULL,
            brand TEXT NOT NULL,
            price_per_day INTEGER NOT NULL,
            days INTEGER NOT NULL CHECK(days > 0),
            total_price INTEGER NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        """)

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.", "error")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped

@app.route("/")
def home():
    return render_template("home.html", cars=CARS)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not name or not email or len(password) < 6:
            flash("Enter your name and email. Password must be at least 6 characters.", "error")
            return render_template("register.html")
        try:
            with db_conn() as db:
                db.execute("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)",
                           (name, email, generate_password_hash(password)))
            flash("Registration successful. Please log in.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("That email is already registered.", "error")
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        with db_conn() as db:
            user = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["user_name"] = user["name"]
            return redirect(url_for("home"))
        flash("Invalid email or password.", "error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("home"))

@app.route("/book/<int:car_id>", methods=["GET", "POST"])
@login_required
def book(car_id):
    car = next((c for c in CARS if c["id"] == car_id), None)
    if car is None:
        flash("Car not found.", "error")
        return redirect(url_for("home"))
    if request.method == "POST":
        try:
            days = int(request.form.get("days", "0"))
            if not 1 <= days <= 365:
                raise ValueError
        except ValueError:
            flash("Please enter a rental duration from 1 to 365 days.", "error")
            return render_template("book.html", car=car)
        total = car["price"] * days
        with db_conn() as db:
            db.execute("""INSERT INTO bookings
                (user_id,car_id,car_name,brand,price_per_day,days,total_price)
                VALUES(?,?,?,?,?,?,?)""",
                (session["user_id"], car["id"], car["name"], car["brand"],
                 car["price"], days, total))
        flash(f"Booking saved. Total: ₹{total:,}", "success")
        return redirect(url_for("my_bookings"))
    return render_template("book.html", car=car)

@app.route("/my-bookings")
@login_required
def my_bookings():
    with db_conn() as db:
        bookings = db.execute(
            "SELECT * FROM bookings WHERE user_id=? ORDER BY id DESC",
            (session["user_id"],)
        ).fetchall()
    return render_template("my_bookings.html", bookings=bookings)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
