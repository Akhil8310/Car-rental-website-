DRIVEEASY CAR RENTAL WEBSITE

Stack: Python Flask, HTML, CSS, SQLite
Prices: Indian rupees (₹)

Run on Windows / VS Code:
1. Extract the ZIP.
2. Open the car_rental_html_python folder in VS Code.
3. Open Terminal > New Terminal.
4. Create a virtual environment:
   python -m venv venv
5. Activate:
   .\venv\Scripts\Activate.ps1
   If blocked, run:
   Set-ExecutionPolicy -Scope Process Bypass
   Then activate again.
6. Install:
   pip install -r requirements.txt
7. Run:
   python app.py
8. Visit http://127.0.0.1:5000

CUSTOMIZE CARS:
Open app.py and edit the CARS list near the top.
Each car has id, name, brand, price (rupees per day), and image (emoji).
Keep each car id unique. Save the file; Flask debug mode reloads it.

Features:
- Home page
- Register and login
- Book a car for 1 to 365 days
- Price calculation in rupees
- My Bookings per logged-in account
- SQLite stores accounts and booking history

Security note:
This is a local educational demo. Before public deployment, set a strong
random secret key, disable debug mode, add CSRF protection, HTTPS, rate
limiting and appropriate privacy safeguards. Do not collect real payment
details. The booking is a demo record, not a paid reservation.
